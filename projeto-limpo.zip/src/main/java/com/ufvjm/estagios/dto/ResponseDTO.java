package com.ufvjm.estagios.dto;

import com.ufvjm.estagios.entities.enums.Role;

import java.util.UUID;

public record ResponseDTO (UUID id, String name, String token, String role, UUID profileId){
    /*public ResponseDTO(UUID id, String name, String token, String role) {
        this(id, name, token, role, null);
    }*/
}
