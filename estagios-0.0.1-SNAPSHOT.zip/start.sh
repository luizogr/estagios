#!/bin/bash
java -jar -Dspring.profiles.active=prod estagios-0.0.1-SNAPSHOT.jar